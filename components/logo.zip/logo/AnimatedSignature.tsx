"use client";

import { useEffect, useState } from "react";
import SignatureCanvas from "./SignatureCanvas";

export default function AnimatedSignature() {
  const [showM1, setShowM1] = useState(false);
  const [showModels, setShowModels] = useState(false);
  const [showM2, setShowM2] = useState(false);
  const [showMisfits, setShowMisfits] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setShowM1(true), 200);
    const t2 = setTimeout(() => setShowModels(true), 2200);
    const t3 = setTimeout(() => setShowM2(true), 2800);
    const t4 = setTimeout(() => setShowMisfits(true), 4600);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, []);

  return (
    <SignatureCanvas
      showM1={showM1}
      showModels={showModels}
      showM2={showM2}
      showMisfits={showMisfits}
    />
  );
}